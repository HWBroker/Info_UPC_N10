
########################################################################
# 			NO EDITEU A PARTIR D'AQUESTA LÍNIA.
########################################################################
def ok(l):
	
	return len(l.replace(' ','')) > 0

def llegeix_matriu ():
	
	M = []
	
	s = input()
	
	while ok(s):
	
		s = s.split()
		s = list(map(int,s))	
		M.append(s)
		
		try: s = input()
		except EOFError as e: s = ''
	
	return M

def escriu_matriu (M):
	
	for f in M:
		for c in f:
			print (c,end=' ')
		print()
	
m = llegeix_matriu()
r = matriu_identitat(m)
print(r)



